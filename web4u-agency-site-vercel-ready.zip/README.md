# web4u — Digital Experiences Studio

React 19 + Vite 7 + Tailwind 4 + Three.js (react-three-fiber) single-page site, bundled to a single self-contained `dist/index.html` via `vite-plugin-singlefile`.

## Local development

```bash
npm install
npm run dev
```

## Production build

```bash
npm run build
npm run preview   # preview the production build locally
```

Build output goes to `dist/` — because of `vite-plugin-singlefile`, the whole app (JS + CSS) is inlined into one `dist/index.html`.

---

## Deploy to Vercel

This repo is already configured for Vercel (`vercel.json` — framework: `vite`, build: `npm run build`, output: `dist`). No extra setup needed.

**Option A — via GitHub (recommended):**
1. Push this project to a GitHub repo.
2. Go to [vercel.com/new](https://vercel.com/new), import the repo.
3. Vercel auto-detects the settings from `vercel.json`. Click **Deploy**.

**Option B — via Vercel CLI:**
```bash
npm install -g vercel
vercel        # first deploy, follow the prompts
vercel --prod # promote to production
```

No environment variables are required — this app has no backend/API calls, it's a fully static bundle.

---

## Uploading to Google AI Studio

This project doesn't use the Gemini API — it's a static React/Three.js site — so there's nothing to configure API-key-wise if you bring it into AI Studio's **Build** mode to keep iterating on it with AI help.

AI Studio's Build mode doesn't (yet) have a dedicated "import zip" button in the UI. The current working method is:
1. Open [aistudio.google.com](https://aistudio.google.com) and start a new **Build** app.
2. Before it scaffolds anything, tell the agent you want to upload this project as a zip instead of generating a new one, and attach `web4u-agency-site.zip`.
3. Ask the agent to unpack it into the project and remove any duplicate/starter files it may have scaffolded first.
4. From there you can keep prompting the AI Studio agent to modify the app, and use its built-in **Export → ZIP / GitHub / Deploy to Cloud Run** options whenever you want to take it elsewhere again.

If you only want to *deploy* (not keep editing with Gemini), Vercel above is the simpler path — Vercel doesn't need any Google AI Studio step at all.
